# Contributing to .aikey Format

Want to add your own .aikey personality? Awesome.

1. Fork this repo
2. Add your .aikey file to `/examples/`
3. Submit a pull request with a short description

Tips:
- Keep characters useful, funny, or original
- Use clear behavior and task flow
- No spam or malicious content

Thanks for growing the AI Key library!
